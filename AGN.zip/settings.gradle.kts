rootProject.name = "AuryxGameNews"
include(":app")
